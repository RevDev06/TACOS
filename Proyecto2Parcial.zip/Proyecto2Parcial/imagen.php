<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Imagenes</title>
</head>
<body>
    <center>
        <table border="2">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Imagen</th>
                </tr>
            </thead>
            <tbody>
                <?php

                    include('conexion.php');

                    $query = "SELECT id, nombre, imagen FROM productos";
                    $resultado = $conexion->query($query);
                    while ($row = $resultado-> fetch_assoc()) {
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><img src="data:image/png;base64,<?php echo base64_decode($row['imagen']); ?>"></td>
                </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
    </center>
</body>
</html>