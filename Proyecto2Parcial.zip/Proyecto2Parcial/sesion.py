class userSession():
    def idUser(self):
        self.idUsuario = 1