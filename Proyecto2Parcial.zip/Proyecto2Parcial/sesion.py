class userSession():
    def __init__(self):
        self.idUsuario = 3