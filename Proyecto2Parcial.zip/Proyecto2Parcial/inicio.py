from flask import *
import pymysql
from db import CBD
from sesion import userSession
import re
import base64
from PIL import Image
import io

cbd = CBD()
cbd.conectar()
ses = userSession()

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024

def comprimirImagen(image):
    img = Image.open(image)
    img = img.convert('RGB')
    img.thumbnail((1000, 1000))  
    imgComprimida = io.BytesIO()
    img.save(imgComprimida, format='JPEG', quality=90)  
    return imgComprimida.getvalue()


@app.route('/')
def inicio():
    return render_template('iniciar.html')

@app.route('/index')
def index():
    return render_template('iniciar.html')

@app.route('/carrito')
def carrito():
    return render_template('carrito.html')


@app.route('/guardarImg', methods=['POST'])
def saveImg():
    if request.method == 'POST':
        prdctName = request.form['nombre']
        categoria = request.form['categoria']
        imagen = request.files['imagen']
        tipo = imagen.mimetype
        img_comprimida = comprimirImagen(imagen)
        costo = int(request.form['costo'])
        stock = int(request.form['stock'])
        
        cbd.cursor.execute('INSERT INTO productos (nombre, categoria, imagen, tipo, costo, stock) VALUES (%s, %s, %s, %s, %s, %s)', (prdctName, categoria, img_comprimida, tipo, costo, stock))
        cbd.conection.commit()
    return redirect(url_for('mostrarImages'))


@app.route('/mostrarImgs')
def mostrarImages():
    cbd.cursor.execute('SELECT id, nombre, imagen, tipo, stock FROM productos')
    productos_raw = cbd.cursor.fetchall()

    productos = []
    for producto in productos_raw:
        id, nombre, imagen, tipo, stock = producto
        imagen_base64 = base64.b64encode(imagen).decode("utf-8")
        productos.append((id, nombre, imagen_base64, tipo, stock))

    return render_template('tablaImgs.html', products = productos)

@app.route('/agregar/<string:id_prdct>')
def addPrdctToCar(id_prdct):
    idUser = ses.idUsuario
    idPrdct = id_prdct
    cantPrdcts += 1
    

    cbd.cursor.execute("INSERT INTO carrito (id_user, id_prdct, quant_prdcts, precio_prdct) VALUES (%s, %s, %s, %s) ")



if __name__ == "__main__" :
    app.run(debug=True)