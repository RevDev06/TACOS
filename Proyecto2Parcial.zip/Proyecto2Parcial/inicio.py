from flask import Flask, render_template, request, redirect, url_for, flash
import pymysql
from db import CBD

app = Flask(__name__)

def convertToBinary(filename):
    with open (filename, 'rb') as file:
        binarydata = file.read()
    return binarydata




@app.route('/')
def index():
    return render_template('iniciar.html')

@app.route('/guardarImg', methods=['POST'])
def saveImg():
    if request.method == 'POST':
        namePrdct = request.form['nombre']
        imagen = conv


if __name__ == "__main__" :
    app.run(debug=True)
    cbd = CBD()
    cbd.conectar()