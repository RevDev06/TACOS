from flask import Flask, render_template, request, redirect, url_for, flash
import pymysql
from db import CBD
import re

cbd = CBD()
app = Flask(__name__)

def convertToBinary(filename):
    with open (filename, 'rb') as file:
        binarydata = file.read()
    return binarydata

def convertBinaryToFile(binarydata, filename):
    with open(filename, 'wb') as file:
        file.write(binarydata)


@app.route('/')
def inicio():
    return render_template('iniciar.html')

@app.route('/index')
def index():
    return render_template('iniciar.html')

@app.route('/guardarImg', methods=['POST'])
def saveImg():
    if request.method == 'POST':
        prdctName = request.form['nombre']
        imagen = request.files['imagen'].read()
        
        conection = pymysql.connect(host='localhost', user=cbd.usuarioXampp, passwd='', port=cbd.puertoXampp, db="bd_tacos")
        cursor = conection.cursor()
        cursor.execute('INSERT INTO productos (nombre, imagen) VALUES (%s, %s)', (prdctName, imagen))
        conection.commit()
    return redirect(url_for('mostrarImages'))

@app.route('/mostrarImgs')
def mostrarImages():
    conection = pymysql.connect(host='localhost', user=cbd.usuarioXampp, passwd='', port=cbd.puertoXampp, db="bd_tacos")
    cursor = conection.cursor()
    cursor.execute('SELECT id, nombre, imagen FROM productos')
    productos = cursor.fetchall()
    print(productos)
    return render_template('tablaImgs.html', products = productos)

if __name__ == "__main__" :
    app.run(debug=True)
    cbd.conectar()